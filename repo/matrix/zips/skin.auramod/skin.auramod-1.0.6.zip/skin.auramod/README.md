# AuraMod for Matrix
# I need all the help I  can get , if you like this skin and want to help me fix the Matrix bugs , Please lend a hand ! 

To install you need to install the following deps from these locations , they are all tested to be matrix compatable . but will need to be downloaded and installed from zip.  Note that besides tmdbhelper , the order matters ! 

First make sure This setting is on Any Repositories !!
![image](https://user-images.githubusercontent.com/21133858/110848870-8ee72280-827c-11eb-87a6-0bf68538522c.png)


1. Install jurialmunkey repo (kodi files source ) > https://jurialmunkey.github.io/

2. Install https://github.com/kodi-community-addons/script.module.thetvdb

3. Install https://github.com/kodi-community-addons/script.module.musicbrainz

4. Install https://github.com/kodi-community-addons/script.module.metadatautils

5. Install https://github.com/kodi-community-addons/script.module.cherrypy

6. Install https://github.com/kodi-community-addons/script.skin.helper.service

7. Install https://github.com/kodi-community-addons/script.skin.helper.widgets

8. Install TheMovieDb helper from Jurial's repo

9. install Auramod zip from this exact github (matrix branch ) 

10. For color cycling and some other features you need to install Colorbox  https://github.com/drinfernoo/script.colorbox/tree/matrix
