This is My modfications and fix's for the Auramod Skin .. Auramod mod if you so like to call it :)

This is kodi 18 version , My repo kodi  file source  https://serpentdrago.github.io/

if you want the kodi 19 (matrix) version please switch to Matrix branch , there is no kodi repo for it  > https://github.com/SerpentDrago/skin.auramod/tree/Matrix
